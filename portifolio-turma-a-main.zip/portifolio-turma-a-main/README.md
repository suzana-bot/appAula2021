# portifolio-turma-a
Portifólio de competências e habilidades do Prof. Adriano Castro

08/06 - Aula de introdução ao GitHub, quando a criação de repositório e gerenciamento do mesmo.

08/06 - Houve a aula de integração do GitHub com o VSCODE.

08/06 - Criamos os arquivos iniciais do projeto Bootstrap e jQuery

08/06 - Foi desenvolvido a página inicial do projeto, bem como configurado o GitPages

02/08 - Aula de introdução ao jQuery